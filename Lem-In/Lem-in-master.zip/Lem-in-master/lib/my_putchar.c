/*
** my_putchar.c for my_putchar in /home/tran_1/test/Lem-in/lib
** 
** Created by tran_1
** Login   <tran_1@epitech.eu>
** 
** Started on  Mon Apr 14 13:13:39 2014 tran_1
** Last update Mon Apr 14 13:13:57 2014 tran_1
*/

void	my_putchar(char c)
{
  write(1, &c, 1);
}
