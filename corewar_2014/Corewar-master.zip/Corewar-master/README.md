tran_1
tran_2
mohamm_h
muth_d

To test program:
[root@localhost#] ./asm tdc4.s toto.s

And asm will create a .cor file