/*
** get_next_line.h for get_next_line in /home/tran_1/test/Corewar/includes
** 
** Created by tran_1
** Login   <tran_1@epitech.eu>
** 
** Started on  Tue Apr  1 10:48:14 2014 tran_1
** Last update Tue Apr  1 10:48:21 2014 tran_1
*/

#ifndef		GET_NEXT_LINE_H_
# define	GET_NEXT_LINE_H_
# define	BUFFER_SIZE 4096
# include	<stdlib.h>


char *get_next_line(int fd);

#endif		/* !GET_NEXT_LINE_H_ */
